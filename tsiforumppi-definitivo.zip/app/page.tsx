"use client"

import  from "../js/tema"

export default function SyntheticV0PageForDeployment() {
  return < />
}