-- Criar banco de dados
CREATE DATABASE IF NOT EXISTS tsi_forum CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE tsi_forum;

-- Tabela de usuários
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    tipo ENUM('aluno', 'professor') NOT NULL,
    semestre VARCHAR(50) NULL,
    telefone VARCHAR(20) NULL,
    telefone_raw VARCHAR(20) NULL,
    campus VARCHAR(255) DEFAULT 'IFFar Campus Panambi',
    cidade VARCHAR(100) DEFAULT 'Panambi',
    comprovante VARCHAR(500) NULL,
    foto_perfil VARCHAR(500) NULL,
    status ENUM('ativo', 'inativo', 'pendente') DEFAULT 'ativo',
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_tipo (tipo),
    INDEX idx_status (status)
);

-- Tabela de publicações
CREATE TABLE publicacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    conteudo TEXT NOT NULL,
    imagem VARCHAR(500) NULL,
    likes INT DEFAULT 0,
    editado BOOLEAN DEFAULT FALSE,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_usuario_id (usuario_id),
    INDEX idx_data_criacao (data_criacao)
);

-- Tabela de likes das publicações
CREATE TABLE publicacao_likes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    publicacao_id INT NOT NULL,
    usuario_id INT NOT NULL,
    data_like TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (publicacao_id) REFERENCES publicacoes(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    UNIQUE KEY unique_like (publicacao_id, usuario_id),
    INDEX idx_publicacao_id (publicacao_id),
    INDEX idx_usuario_id (usuario_id)
);

-- Tabela de respostas
CREATE TABLE respostas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    publicacao_id INT NOT NULL,
    usuario_id INT NOT NULL,
    conteudo TEXT NOT NULL,
    imagem VARCHAR(500) NULL,
    editado BOOLEAN DEFAULT FALSE,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (publicacao_id) REFERENCES publicacoes(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_publicacao_id (publicacao_id),
    INDEX idx_usuario_id (usuario_id),
    INDEX idx_data_criacao (data_criacao)
);

-- Tabela de configurações do usuário
CREATE TABLE usuario_configuracoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    tema ENUM('claro', 'escuro', 'sistema') DEFAULT 'claro',
    tamanho_fonte ENUM('pequeno', 'medio', 'grande', 'muito_grande') DEFAULT 'medio',
    alto_contraste BOOLEAN DEFAULT FALSE,
    data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    UNIQUE KEY unique_config (usuario_id)
);
