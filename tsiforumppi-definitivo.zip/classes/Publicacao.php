<?php
require_once 'config/database.php';

class Publicacao {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    // Criar nova publicação
    public function criar($dados) {
        $sql = "INSERT INTO publicacoes (usuario_id, conteudo, imagem) VALUES (:usuario_id, :conteudo, :imagem)";
        
        $params = [
            ':usuario_id' => $dados['usuario_id'],
            ':conteudo' => $dados['conteudo'],
            ':imagem' => $dados['imagem'] ?? null
        ];
        
        return $this->db->insert($sql, $params);
    }
    
    // Listar todas as publicações com dados do usuário
    public function listarTodas() {
        $sql = "SELECT p.*, u.nome, u.tipo, u.semestre, u.foto_perfil,
                       (SELECT COUNT(*) FROM publicacao_likes pl WHERE pl.publicacao_id = p.id) as likes
                FROM publicacoes p 
                INNER JOIN usuarios u ON p.usuario_id = u.id 
                ORDER BY p.data_criacao DESC";
        
        return $this->db->fetchAll($sql);
    }
    
    // Buscar publicação por ID
    public function buscarPorId($id) {
        $sql = "SELECT p.*, u.nome, u.tipo, u.semestre, u.foto_perfil,
                       (SELECT COUNT(*) FROM publicacao_likes pl WHERE pl.publicacao_id = p.id) as likes
                FROM publicacoes p 
                INNER JOIN usuarios u ON p.usuario_id = u.id 
                WHERE p.id = :id";
        
        return $this->db->fetchOne($sql, [':id' => $id]);
    }
    
    // Atualizar publicação
    public function atualizar($id, $conteudo, $usuarioId) {
        $sql = "UPDATE publicacoes SET conteudo = :conteudo, editado = 1 
                WHERE id = :id AND usuario_id = :usuario_id";
        
        $params = [
            ':id' => $id,
            ':conteudo' => $conteudo,
            ':usuario_id' => $usuarioId
        ];
        
        $this->db->query($sql, $params);
        return true;
    }
    
    // Excluir publicação
    public function excluir($id, $usuarioId) {
        $sql = "DELETE FROM publicacoes WHERE id = :id AND usuario_id = :usuario_id";
        $this->db->query($sql, [':id' => $id, ':usuario_id' => $usuarioId]);
        return true;
    }
    
    // Curtir/Descurtir publicação
    public function toggleLike($publicacaoId, $usuarioId) {
        // Verificar se já curtiu
        $sql = "SELECT id FROM publicacao_likes WHERE publicacao_id = :publicacao_id AND usuario_id = :usuario_id";
        $like = $this->db->fetchOne($sql, [':publicacao_id' => $publicacaoId, ':usuario_id' => $usuarioId]);
        
        if ($like) {
            // Remover like
            $sql = "DELETE FROM publicacao_likes WHERE publicacao_id = :publicacao_id AND usuario_id = :usuario_id";
            $this->db->query($sql, [':publicacao_id' => $publicacaoId, ':usuario_id' => $usuarioId]);
            return false; // Removeu o like
        } else {
            // Adicionar like
            $sql = "INSERT INTO publicacao_likes (publicacao_id, usuario_id) VALUES (:publicacao_id, :usuario_id)";
            $this->db->query($sql, [':publicacao_id' => $publicacaoId, ':usuario_id' => $usuarioId]);
            return true; // Adicionou o like
        }
    }
    
    // Verificar se usuário curtiu a publicação
    public function usuarioCurtiu($publicacaoId, $usuarioId) {
        $sql = "SELECT id FROM publicacao_likes WHERE publicacao_id = :publicacao_id AND usuario_id = :usuario_id";
        $like = $this->db->fetchOne($sql, [':publicacao_id' => $publicacaoId, ':usuario_id' => $usuarioId]);
        return $like !== false;
    }
    
    // Buscar usuários que curtiram uma publicação
    public function buscarLikes($publicacaoId) {
        $sql = "SELECT u.id, u.nome FROM publicacao_likes pl 
                INNER JOIN usuarios u ON pl.usuario_id = u.id 
                WHERE pl.publicacao_id = :publicacao_id";
        
        return $this->db->fetchAll($sql, [':publicacao_id' => $publicacaoId]);
    }
}
?>
