<?php
require_once 'config/database.php';

class Usuario {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    // Criar novo usuário
    public function criar($dados) {
        // Criptografar senha
        $senhaHash = password_hash($dados['senha'], PASSWORD_DEFAULT);
        
        $sql = "INSERT INTO usuarios (nome, email, senha, tipo, semestre, telefone, telefone_raw, campus, cidade, comprovante, status) 
                VALUES (:nome, :email, :senha, :tipo, :semestre, :telefone, :telefone_raw, :campus, :cidade, :comprovante, :status)";
        
        $params = [
            ':nome' => $dados['nome'],
            ':email' => $dados['email'],
            ':senha' => $senhaHash,
            ':tipo' => $dados['tipo'],
            ':semestre' => $dados['semestre'] ?? null,
            ':telefone' => $dados['telefone'] ?? null,
            ':telefone_raw' => $dados['telefone_raw'] ?? null,
            ':campus' => $dados['campus'] ?? 'IFFar Campus Panambi',
            ':cidade' => $dados['cidade'] ?? 'Panambi',
            ':comprovante' => $dados['comprovante'] ?? null,
            ':status' => 'ativo'
        ];
        
        return $this->db->insert($sql, $params);
    }
    
    // Verificar login
    public function login($email, $senha) {
        $sql = "SELECT * FROM usuarios WHERE email = :email AND status = 'ativo'";
        $usuario = $this->db->fetchOne($sql, [':email' => $email]);
        
        if ($usuario && password_verify($senha, $usuario['senha'])) {
            // Remover senha do retorno por segurança
            unset($usuario['senha']);
            return $usuario;
        }
        
        return false;
    }
    
    // Verificar se email já existe
    public function emailExiste($email) {
        $sql = "SELECT id FROM usuarios WHERE email = :email";
        $resultado = $this->db->fetchOne($sql, [':email' => $email]);
        return $resultado !== false;
    }
    
    // Buscar usuário por ID
    public function buscarPorId($id) {
        $sql = "SELECT * FROM usuarios WHERE id = :id";
        $usuario = $this->db->fetchOne($sql, [':id' => $id]);
        
        if ($usuario) {
            unset($usuario['senha']); // Remover senha por segurança
        }
        
        return $usuario;
    }
    
    // Atualizar dados do usuário
    public function atualizar($id, $dados) {
        $campos = [];
        $params = [':id' => $id];
        
        foreach ($dados as $campo => $valor) {
            if ($campo === 'senha') {
                $campos[] = "senha = :senha";
                $params[':senha'] = password_hash($valor, PASSWORD_DEFAULT);
            } else {
                $campos[] = "$campo = :$campo";
                $params[":$campo"] = $valor;
            }
        }
        
        $sql = "UPDATE usuarios SET " . implode(', ', $campos) . " WHERE id = :id";
        $this->db->query($sql, $params);
        
        return true;
    }
    
    // Buscar configurações do usuário
    public function buscarConfiguracoes($usuarioId) {
        $sql = "SELECT * FROM usuario_configuracoes WHERE usuario_id = :usuario_id";
        return $this->db->fetchOne($sql, [':usuario_id' => $usuarioId]);
    }
    
    // Salvar configurações do usuário
    public function salvarConfiguracoes($usuarioId, $configuracoes) {
        $sql = "INSERT INTO usuario_configuracoes (usuario_id, tema, tamanho_fonte, alto_contraste) 
                VALUES (:usuario_id, :tema, :tamanho_fonte, :alto_contraste)
                ON DUPLICATE KEY UPDATE 
                tema = :tema, tamanho_fonte = :tamanho_fonte, alto_contraste = :alto_contraste";
        
        $params = [
            ':usuario_id' => $usuarioId,
            ':tema' => $configuracoes['tema'] ?? 'claro',
            ':tamanho_fonte' => $configuracoes['tamanho_fonte'] ?? 'medio',
            ':alto_contraste' => $configuracoes['alto_contraste'] ? 1 : 0
        ];
        
        $this->db->query($sql, $params);
        return true;
    }
}
?>
