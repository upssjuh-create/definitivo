<?php
require_once 'config/database.php';

class Resposta {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    // Criar nova resposta
    public function criar($dados) {
        $sql = "INSERT INTO respostas (publicacao_id, usuario_id, conteudo, imagem) 
                VALUES (:publicacao_id, :usuario_id, :conteudo, :imagem)";
        
        $params = [
            ':publicacao_id' => $dados['publicacao_id'],
            ':usuario_id' => $dados['usuario_id'],
            ':conteudo' => $dados['conteudo'],
            ':imagem' => $dados['imagem'] ?? null
        ];
        
        return $this->db->insert($sql, $params);
    }
    
    // Listar respostas de uma publicação
    public function listarPorPublicacao($publicacaoId) {
        $sql = "SELECT r.*, u.nome, u.tipo, u.semestre, u.foto_perfil
                FROM respostas r 
                INNER JOIN usuarios u ON r.usuario_id = u.id 
                WHERE r.publicacao_id = :publicacao_id 
                ORDER BY r.data_criacao ASC";
        
        return $this->db->fetchAll($sql, [':publicacao_id' => $publicacaoId]);
    }
    
    // Atualizar resposta
    public function atualizar($id, $conteudo, $usuarioId) {
        $sql = "UPDATE respostas SET conteudo = :conteudo, editado = 1 
                WHERE id = :id AND usuario_id = :usuario_id";
        
        $params = [
            ':id' => $id,
            ':conteudo' => $conteudo,
            ':usuario_id' => $usuarioId
        ];
        
        $this->db->query($sql, $params);
        return true;
    }
    
    // Excluir resposta
    public function excluir($id, $usuarioId) {
        $sql = "DELETE FROM respostas WHERE id = :id AND usuario_id = :usuario_id";
        $this->db->query($sql, [':id' => $id, ':usuario_id' => $usuarioId]);
        return true;
    }
    
    // Contar respostas de uma publicação
    public function contarPorPublicacao($publicacaoId) {
        $sql = "SELECT COUNT(*) as total FROM respostas WHERE publicacao_id = :publicacao_id";
        $resultado = $this->db->fetchOne($sql, [':publicacao_id' => $publicacaoId]);
        return $resultado['total'];
    }
}
?>
